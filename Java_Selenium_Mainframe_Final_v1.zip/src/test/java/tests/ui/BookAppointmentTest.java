package tests.ui;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import init.BaseTest;
import pages.HealthCareAppointmentPage;
import pages.HealthCareLoginPage;
import utils.WebUtil;


public class BookAppointmentTest extends BaseTest{

	HealthCareLoginPage login;
	HealthCareAppointmentPage appointment;
	WebUtil testUtil;

	@Parameters({"browserType", "appURL"})
	@BeforeMethod
	public void pageInit(String browserType, String appURL) {
		login = new HealthCareLoginPage();
		testUtil = new WebUtil();
		
		
		testUtil.launchBrowser(browserType, appURL);
	}

	/**
	 * This test method is created to verify the appointment functionality 
	 */
	@Test
	public void makeappointment() {

		//  Writing test information to Extend Report
		getExtentTest().info("Application opened successfully");
				
		login.clickOnAppoitment();

		getExtentTest().pass("Navigated to Login page");

		appointment=login.login("John Doe", "ThisIsNotAPassword");

		getExtentTest().pass("Navigated to Appointment page");

		appointment.makeappointment("Tokyo CURA Healthcare Center", "Medicare", "03/10/2023", "Test");

		// *** Asserting the expected result
		Assert.assertTrue(appointment.validateappointment().equals(true));


	}

	@Test
	public void HealthCareLogin() {

		//  Writing test information to Extend Report
		getExtentTest().info("Application opened successfully");
	
		login.clickOnAppoitment();

		// *** Asserting the expected result
		Assert.assertTrue(login.validateLoginPage().equals(true));
		
		getExtentTest().pass("Navigated to Login page");


	}

}
