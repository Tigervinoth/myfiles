package tests.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import apimodel.APIBuilder;
import apimodel.objects.Login;
import init.BaseTest;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import utils.APIUtil;

public class APITest extends BaseTest {

	APIUtil apiUtil;
	APIBuilder build=new APIBuilder();

	/**
	 * This test method validates response using jsonpath
	 */
	@Test(enabled=true)
	public void validateResponseUsingJsonpath() {

		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: validate repsonse using jsonpath");

		// Fetching URl from property file
		String appURI=prop.getProperty("api_url");

		// Initializing APIUtil constructor
		apiUtil = new APIUtil(appURI,"/api/users");

		// setting up the query parameters
		Map<String, String> queryParams = new HashMap<>();
		queryParams.put("page", "2");
		apiUtil.setQueryParams(queryParams);

		// Invoking the Get method to fetch server response
		apiUtil.invokeGET();
		Response response = apiUtil.getResponse();        

		// Writing test results to Extend Report
		getExtentTest().info("Response from the server is: "+response.asPrettyString());

		// Asserting using soft assert
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), 200);
		softAssert.assertEquals(response.getBody().jsonPath().get("data[0].first_name"),"Michael");
		softAssert.assertAll();

	}

	/**
	 * This test method validates response using json schema
	 */
	@Test(enabled=true)
	public void validateSchema() {
	
		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: validate schema");

		// Fetching URl from property file
		String appURI=prop.getProperty("api_url");

		// Initializing APIUtil constructor
		apiUtil = new APIUtil(appURI,"/api/users");

		// setting up the query parameters
		Map<String, String> queryParams = new HashMap<>();
		queryParams.put("page", "2");        
		apiUtil.setQueryParams(queryParams);

		// Invoking the Get method to fetch server response
		apiUtil.invokeGET();
		Response response = apiUtil.getResponse();

		// Writing test results to Extend Report
		getExtentTest().info("Response from the server is: "+response.asPrettyString());

		// Validating schema using JsonSchemaValidator
		APIUtil.validateJsonSchema(response.getBody().asString(), "schemas/getUser.json");

	}

	/**
	 * This test method validates response using json schema
	 */
	@Test(enabled=true)
	public void invalidvalidateSchema() {

		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: validate schema");

		// Fetching URl from property file
		String appURI=prop.getProperty("api_url");

		apiUtil = new APIUtil(appURI,"/api/users");

		// setting up the query parameters
		Map<String, String> queryParams = new HashMap<>();
		queryParams.put("page", "2");        
		apiUtil.setQueryParams(queryParams);

		// Invoking the Get method to fetch server response
		apiUtil.invokeGET();
		Response response = apiUtil.getResponse();

		// Writing test results to Extend Report
		getExtentTest().info("Response from the server is: "+response.asPrettyString());

		// Validating schema using JsonSchemaValidator
		APIUtil.validateJsonSchema(response.getBody().asString(), "schemas/getUserInvalid.json");

	}

	/**
	 * In this test method, Request Payload is passed from external JSON file
	 */
	@Parameters({ "appURI" })
	@Test
	public void LoginUsingPayload(String URI) throws IOException {

		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: Login using external payload file");

		String ACCESS_TOKEN=new APIBuilder().getAccessToken(URI, "/auth/oauth2/v2/token");

		String endpoint = "/api/1/login/auth";

		apiUtil = new APIUtil(URI, endpoint);

		// Loading the request payload from external file 
		Map<String, Object> body = build.readpayload("src/test/resources/data/loginpayload.json");

		// setting up the request parameters
		apiUtil.setOauth2Authentication(ACCESS_TOKEN);
		apiUtil.setBody(body);

		apiUtil.invokePOST();
		Response response = apiUtil.getResponse();

		// Writing test results to Extend Report
		getExtentTest().info("Response from the server is: "+response.asPrettyString());

		// Asserting using soft assert
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), 200);
		softAssert.assertEquals(response.getBody().jsonPath().get("data[0].status"),"Authenticated");
		softAssert.assertAll();

	}

	/**
	 * In this test method, Request Payload is passed from POJO class and passing parameters from external EXCEL file
	 * Hamcrest Library is used to validate Response
	 */
	@Test(enabled=true,dataProvider = "exceldata")
	public void LoginUsingExcelData(String strTestcase, String URL,String strEmailID,String strPassword,String domain) {

		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: Login Using POJO class");

		String ACCESS_TOKEN=new APIBuilder().getAccessToken(URL, "/auth/oauth2/v2/token");

		String endpoint = "/api/1/login/auth";

		apiUtil = new APIUtil(URL.toString(), endpoint);

		// Setting up POJO class values from excel
		Login login = new Login();
		login.setUsername_or_email(strEmailID);
		login.setPassword(strPassword);
		login.setSubdomain(domain);

		// Converting POJO class to Hashmap
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = mapper.convertValue(login, new TypeReference<Map<String, Object>>() {});

		apiUtil.setOauth2Authentication(ACCESS_TOKEN);
		apiUtil.setBody(map);

		apiUtil.invokePOST();

		Response response = apiUtil.getResponse();

		// Writing test results to Extend Report
		getExtentTest().info("Response from the server is: "+response.asPrettyString());

		// Validating response using resposne specification
		build.verifyusingresponseSpec(response,200);

		// Validating response details using Hamcrest
		build.responseValidation(response, "data[0].status", "Authenticated"); 

	}

	

	/**
	 * This test method validates response using APIChaining Create and Update users
	 */
	@Test
	public void APIChaining_Create_Update() {

		// Writing test information to Extend Report
		getExtentTest().info("Execution started for test case: APIChainig by Creating User");

		String appURI=prop.getProperty("api_url");

		apiUtil = new APIUtil(appURI,"/api/users");

		// Loading the request payload from external file 
		Map<String, Object> body = build.readpayload("src/test/resources/data/createuser.json");        
		apiUtil.setBody(body);

		apiUtil.invokePOST();
		Response response = apiUtil.getResponse();

		// Validating response using resposne specification
		build.verifyusingresponseSpec(response,201);

		// Extracting id from response using jsonpath
		JsonPath jsonPath = new JsonPath(response.asString()); 		
		String id= jsonPath.getString("id").trim(); 

		// Updating the user details 
		apiUtil = new APIUtil(appURI,"/api/users/"+id);

		body = new HashMap<>();
		body.put("name", "vinoth");        
		apiUtil.setBody(body);

		apiUtil.invokePATCH();
		response = apiUtil.getResponse();

		// Validating response details using Hamcrest
		build.responseValidation(response, "name", "vinoth");        


	}

}
