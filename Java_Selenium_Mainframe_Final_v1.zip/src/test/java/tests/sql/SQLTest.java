package tests.sql;

import java.sql.ResultSet;

import org.testng.annotations.Test;
import init.BaseTest;
import utils.SqlUtil;

public class SQLTest extends BaseTest{

	SqlUtil util = new SqlUtil();

	/**
	 * This test method is used to fetch the data from Database 
	 */
	@Test
	public void FetchingSQLData() {

		try {

			// Initilize the connection variables from property file
			String query=prop.getProperty("select_query");

			String url=prop.getProperty("dburl");

			String id =prop.getProperty("username");

			String password=prop.getProperty("password");

			getExtentTest().info("Executing the query to fetch data from DB");

			// Connect to the datatbase using executeSelect method which returns data in Resultset object
			ResultSet result=util.executeSelect(url,id,password,query);

			if(!(result==null)){						

				while(result.next()){

					int a=result.getInt(1);
					String b=result.getString(2);
					String c=result.getString(3); 

					getExtentTest().info(a+"---"+b+"----"+c);
				}

				result.close();
			}
			else {

				getExtentTest().fail("Returned Resultset is empty");
			}
		} catch (Exception e) {

			getExtentTest().fail("Exception occured in connecting the DB "+e.getMessage());

		}



	}

	/**
	 * This test method is used to update the data to Database 
	 */
	@Test
	public void UpdatingDB() {


		try {
			
			// Initilize the connection variables from property file
			String update=prop.getProperty("update_query");

			String url=prop.getProperty("dburl");

			String id =prop.getProperty("username");

			String password=prop.getProperty("password");

			getExtentTest().info("Executing the query to update the data to DB");

			// Connect to the datatbase using executeUpdate method which returns the row details
			int rowsUpdated = util.executeUpdate(url,id,password,update);

			if (rowsUpdated > 0) {
				getExtentTest().info("Data was updated successfully! and rows Updated are: "+rowsUpdated );
			}
			else {

				getExtentTest().fail("No rows are updated or Data is not available in DB");
			}

		} catch (Exception e) {

			getExtentTest().fail("Exception occured in connecting the DB "+e.getMessage());

		}



	}
}
