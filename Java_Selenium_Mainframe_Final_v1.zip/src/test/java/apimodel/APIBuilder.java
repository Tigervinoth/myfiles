package apimodel;

import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;

import com.codoid.products.fillo.Recordset;
import com.google.gson.Gson;

import constants.GenericConstants;
import init.InitTest;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import utils.APIUtil;
import utils.ExcelUtil;

public class APIBuilder extends InitTest{


	/**
	 * This method is used to setup RequestSpecification 
	 */
	public RequestSpecification setuprequestspec() {

		RequestSpecification requestspec = new RequestSpecBuilder()
				.addHeader("Content-Type", "application/json")
				.addHeader("Accept", "application/json")		
				.build();

		return requestspec;


	}

	/**
	 * This method is used to setup ResponseSpecification 
	 */
	public void verifyusingresponseSpec(Response response,int code) {

		try {
			ResponseSpecification responseSpec=new ResponseSpecBuilder()
					.expectStatusCode(code)
					.expectContentType(ContentType.JSON)
					.expectResponseTime(Matchers.lessThan(GenericConstants.API_WAIT))
					.build();

			response.then().spec(responseSpec);
			getExtentTest().info("Validation successful for response using response specification");
		}
		catch(Exception e) {

			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Response from the server is: " + e);
			Assert.fail("Response from the server is: " + e);
		}
	}


	/**
	 * This method is used to validate repsonse using hamcrest 
	 */
	public void responseValidation(Response response,String key, String value) {

		try {

			// Hamcrest validation -- EqualTo
			response.then().body(key, equalTo(value));
			
		}
		catch(Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Response from the server is: " + e);
			Assert.fail("Response from the server is: " + e);
			
		}

	}	

	/**
	 * This method reads payload from external file
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> readpayload(String filepath) {
		

		Gson gson = new Gson();    
		// create a reader
		Reader reader = null;
		try {
			reader = Files.newBufferedReader(Paths.get(filepath));
		} catch (IOException e) {
			getExtentTest().info("Error Reading file "+e);
		}

		// convert JSON file to map
		Map<String,Object> map = gson.fromJson(reader, Map.class);
		
		return map;
	}


	/**
	 * This method is used to get Access Token
	 * @return ACCESS_TOKEN
	 */
	public String getAccessToken(String URI,String endpoint) {

		APIUtil apiUtil = new APIUtil(URI,endpoint);

		// setting up the request parameters
		Map<String, Object> body = new HashMap<>();
		body.put("grant_type", "client_credentials");
		apiUtil.setBasicAuthentication(prop.getProperty("cliend_id"),prop.getProperty("client_secret"));
		apiUtil.setBody(body);

		apiUtil.invokePOST();
		Response response =  apiUtil.getResponse(); 

		// Extracting Access token
		JsonPath jsonPath = new JsonPath(response.asString()); 
		String ACCESS_TOKEN = jsonPath.getString("access_token").trim(); 

		return ACCESS_TOKEN;


	}

	@DataProvider(name="exceldata")
	public Object[][] getData(ITestContext objContext)
	{
		Object[][] objExcelData = new String[0][1];

		try {

			String strTestName = objContext.getCurrentXmlTest().getParameter("TestName");
			
			String strDataFileLocation = init_prop().getProperty("apiDataFile");

			ExcelUtil objExcelUtil = new ExcelUtil();

			Recordset objRS = objExcelUtil.getExcelData(strTestName,strDataFileLocation);

			int intRecordCounter = 0;
			int intDataCounter = 0;

			int intTotalFieldCount = objRS.getFieldNames().size();
			int intTotalRecordCount = objRS.getCount();

			String data[][] = new String[intTotalRecordCount][intTotalFieldCount - 1];

			while (objRS.next()) {
				while (intDataCounter < intTotalFieldCount-1) {
					data[intRecordCounter][intDataCounter] = objRS.getField(intDataCounter + 1).value();
					intDataCounter++;
				}
				intDataCounter =    0;
				intRecordCounter++;
			}

			objExcelData = data;

		} catch(Exception e)
		{
			System.out.println(e.getStackTrace());
		}
		return objExcelData;
	}

}
