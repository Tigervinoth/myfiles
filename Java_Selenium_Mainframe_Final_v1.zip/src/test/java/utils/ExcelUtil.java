package utils;

import java.io.File;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class ExcelUtil {

	/**
	 * This method is used to fetch data from excel using Filo library 
	 */
    public Recordset getExcelData(String strTestcase,String strDataFileLocation )
    {

        String strBaseLocation = new File("").getAbsolutePath();

        String strFullDataFileLocation = strBaseLocation + File.separatorChar + "src" + File.separatorChar + "test" + File.separatorChar + "resources" + File.separatorChar + "data" + File.separatorChar + strDataFileLocation;

        Fillo objFillo = new Fillo();
        Recordset objRS = null;

        try
        {
            Connection objConnection = objFillo.getConnection(strFullDataFileLocation);
            String strQuery = "select * from data where Testcase='" + strTestcase + "'";

            objRS = objConnection.executeQuery(strQuery);

        } catch(Exception e)
        {
            System.out.println(e.getStackTrace());
        }

        return objRS;

    }

}
