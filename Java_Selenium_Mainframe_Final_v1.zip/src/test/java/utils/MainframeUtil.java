package utils;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.h3270.host.Field;
import org.testng.Assert;

import init.InitTest;
import net.sf.f3270.FieldIdentifier;


public class MainframeUtil  extends InitTest{

	
    /**
     * This method is created to connect to terminal
     * @param hostname
     * @param port
     */
    public void launchterminal(String hostname,int port) {
    	
    	init_terminal(hostname, port);
    	getTerminal().connect();
    }
     
    /**
     * This method is created to write a values to terminal using Field Identifier
     * @param Field
     * @param Value
     */
	public void writeToField(String Field, String Value) {

		try {
			getTerminal().write(new FieldIdentifier(Field), Value);
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to write value to the server on Field - " + Field);
            Assert.fail("Unable to write value to the server on Field - " + Field +"- Value- "+Value);
		}
	}

    /**
     * This method is created to send keys to terminal
     * @param Value
     */
	public void sendKeys(String Value) {

		try {
			getTerminal().type(Value);
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to write value to the server - " + Value);
            Assert.fail("Unable to write value to the server -- "+Value);
		}
	}
	
    /**
     * This method is created to read data from terminal using Field name
     * @param Field
     */
	public String readFieldData(String Field) {

		try {
			String data=getTerminal().read(new FieldIdentifier(Field));
			return data;
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to read value from the server on Field - " + Field);
            Assert.fail("Unable to read value from the server on Field - " + Field);
            return null;
		}
		
	}
	
    /**
     * This method is created to read data from terminal using row number
     * @param line
     */
	public String getDataFromLine(int line) {

		try {
			
			String data=getTerminal().getLine(line);
			return data;
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to read value from the server on line - "+line);
            Assert.fail("Unable to read value from the server on line - "+line);
            return null;
		}
		
	}

    /**
     * This method is created to send ENTER key to terminal
     */
    public void sendEnterKey() {
		try {
			Thread.sleep(1800); //Demo
			getTerminal().enter();
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to send Enter Key to the server");
            Assert.fail("Unable to send Enter Key to the server");
		}
    }
    
    /**
     * This method is created to send TAB Key to terminal
     * @param times
     */
    public void sendTab(int times) {
		try {
			for(int i=1;i<=times;i++) {
				getTerminal().tab();
			}
			
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to send TAB Key to the server");
            Assert.fail("Unable to send TAB Key to the server");
		}
    }
    
    /**
     * This method is created to send PF Key to terminal based on Function key number
     * @param key
     */
    public void sendFunctionKey(int key) {
		try {
			getTerminal().pf(key);
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to send PF Key to the server");
            Assert.fail("Unable to send PF Key to the server");
		}
    }

    /**
     * This method is created to move cursor position in mainframe terminal
     * @param row
     * @param col
     */
    public void setCursorPOS(int row, int col) {
		try {
			getTerminal().moveCursor(row, col);
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to move cursor to the server");
            Assert.fail("Unable to move cursor to the server");
		}
    }
    
    
    public void assertText(String text) {
    	
    	if(!getTerminal().getScreenText().contains(text)) {
    		Assert.fail("Unable to find the text on the server = "+text);
    	}
        
    }
    	
	
    /**
     * This method is created to wait for certain time interval
     * @param millis
     */
	protected void sleep(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}
	
    /**
     * This method is used to disconnect the terminal
     */
    public void disconnect() {
		try {
			getTerminal().disconnect();
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to disconect from the server");
            Assert.fail("Unable to disconect from the server");
		}
    }
    
    /**
     * This method is created to print data from the screen
     */
    public void printScreen() {
    	
    	try {
    		PrintStream output=new PrintStream(new FileOutputStream("target/mainframe.txt",true));
			getTerminal().printScreen(output);
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to print data from the server");
            Assert.fail("Unable to print data from the server");	
		}
    }
    
    /**
     * This method is created to verify if from terminal has Field label
     * @param Field
     */
    public boolean checkLabel(String Field) {
    	
    	try {
    		return getTerminal().screenHasLabel(new FieldIdentifier(Field));
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to find label from the server");
            Assert.fail("Unable to find label from the server");
		}
		return false;
    }
    
    /**
     * This method is created to get data from terminal using Field label
     * @param Field
     */
    public Field getfield(String Field) {
    	
    	try {
    		return getTerminal().getField(new FieldIdentifier(Field));
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to get field from the server");
            Assert.fail("Unable to get field from the server");
		}
		return null;
    }
}
