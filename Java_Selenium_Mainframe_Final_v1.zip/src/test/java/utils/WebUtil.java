
package utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.sukgu.Shadow;
import constants.GenericConstants;
import init.InitTest;

public class WebUtil extends InitTest {


	/**
	 * This method launches browser using user inputs either from MVN CMD or config file
	 */	
	public void launchBrowser(String browserType, String appURL) {		

		try {
			String browserName;
			// Initiating Browser using user inputs either from MVN CMD or config file
			if(!System.getProperty("browser").isEmpty()) browserName = System.getProperty("browser");
			
			else browserName = browserType;
			
			init_driver(browserName);
			getDriver().manage().deleteAllCookies();
			getDriver().manage().window().maximize();
			getDriver().get(appURL);
			getDriver().manage().timeouts().implicitlyWait(GenericConstants.IMPLICIT_WAIT, TimeUnit.SECONDS);

		}
		catch(Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().fail("Unable to Open brrowser "+e);
			Assert.fail("Unable to Open brrowser ");
		}
	}

	/**
	 * This method is created to accept an alert
	 */
	public void switchToAlertAccept() {
		Alert alert = null;
		try {
			alert = getDriver().switchTo().alert();
			alert.accept();
		} catch(Exception objException) {
			try {
				alert = getDriver().switchTo().alert();
				alert.accept();
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to accept the alert");
				Assert.fail("Unable to accept the alert");
			}
		}
	}

	/**
	 * This method is created to dismiss an alert
	 */
	public void switchToAlertDismiss() {
		Alert alert = null;
		try {
			alert = getDriver().switchTo().alert();
			alert.dismiss();
		} catch(Exception objException) {
			try {
				alert = getDriver().switchTo().alert();
				alert.dismiss();
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to dismiss the alert");
				Assert.fail("Unable to dismiss the alert");
			}
		}
	}

	/**
	 * This method is created to fetch text from alert
	 *
	 * @return
	 */
	public String fetchTextFromAlert() {

		Alert alert = null;
		String strAlertText = null;
		try {
			alert = getDriver().switchTo().alert();
			strAlertText = alert.getText();
		} catch(Exception objException) {
			try {
				alert = getDriver().switchTo().alert();
				strAlertText = alert.getText();
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to retrieve text from the alert");
				Assert.fail("Unable to retrieve text from the alert");
			}
		}
		return(strAlertText);
	}
	/**
	 * This method is created to switch to another window handle
	 */
	public void switchToWindowFromParent() {

		try {
			String objParentWindow = getDriver().getWindowHandle();
			Set<String> listWindows = getDriver().getWindowHandles();

			for (String objWindowHandle : listWindows) {
				if(!objWindowHandle.equalsIgnoreCase(objParentWindow)) {
					getDriver().switchTo().window(objWindowHandle);
					break;
				}
			}
		} catch (Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Unable to switch to the window from parent window");
			Assert.fail("Unable to switch to the window from parent window");
		}
	}

	/**
	 * This method is created to select a value from a dropdown using visible text.
	 *
	 * @param strUIName
	 * @param strByObject
	 * @param strOption
	 */
	public void selectFromDropdownByVisibleText(String strUIName,By strByObject, String strOption) {

		WebElement objClickElement = null;
		try {
			objClickElement = waitForClickability(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else {
				objClickElement = waitForClickability(strByObject);
				Select objSelect = new Select(objClickElement);
				objSelect.selectByVisibleText(strOption);
			}
		} catch (Exception objException) {
			try {
				Select objSelect = new Select(objClickElement);
				objSelect.selectByVisibleText(strOption);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to select " + strOption + " in the drop down - " + strUIName);
				Assert.fail("Unable to select " + strOption + " in the drop down - " + strUIName);
			}
		}

		if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
			getExtentTest().info("Select " + strOption + " from the drop down - " + strUIName);

		//select.selectByIndex(index);
		//select.deselectByValue(option);
		//List<WebElement> element = select.getOptions();
	}

	/**
	 * This method is created to select a value from a dropdown using index.
	 *
	 * @param strUIName
	 * @param strByObject
	 * @param intIndex
	 */
	public void selectFromDropdownByIndex(String strUIName,By strByObject, int intIndex) {

		WebElement objClickElement = null;
		try {
			objClickElement = waitForClickability(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else {
				Select objSelect = new Select(objClickElement);
				objSelect.selectByIndex(intIndex);
			}
		} catch (Exception objException) {
			try {
				objClickElement = waitForClickability(strByObject);
				Select objSelect = new Select(objClickElement);
				objSelect.selectByIndex(intIndex);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to select the value of index: " + intIndex + " in the drop down - " + strUIName);
				Assert.fail("Unable to select the value of index: " + intIndex + " in the drop down - " + strUIName);
			}
		}

		if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
			getExtentTest().info("Selected the value of Index: " + intIndex + " from the drop down - " + strUIName);

	}

	/**
	 * This method is created to select a value from a dropdown using index.
	 *
	 * @param strUIName
	 * @param strByObject
	 * @param strValue
	 */
	public void selectFromDropdownByValue(String strUIName,By strByObject, String strValue) {

		WebElement objClickElement = null;
		try {
			objClickElement = waitForClickability(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else {
				Select objSelect = new Select(objClickElement);
				objSelect.selectByValue(strValue);
			}
		} catch (Exception objException) {
			try {
				objClickElement = waitForClickability(strByObject);
				Select objSelect = new Select(objClickElement);
				objSelect.selectByValue(strValue);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Unable to select the value: " + strValue + " in the drop down - " + strUIName);
				Assert.fail("Unable to select the value: " + strValue + " in the drop down - " + strUIName);
			}
		}

		if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
			getExtentTest().info("Selected the value: " + strValue + " from the drop down - " + strUIName);
	}


	/**
	 * This method is created to take screenshot
	 *
	 * @param testcaseName
	 * @return
	 */
	public String takeScreenshot(String testcaseName) {

		String strReturnValue = null;

		try {
			String date = dateFormat();
			File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			String screenshotPath= System.getProperty("user.dir")+"/test-output/TestNG/Spark/" + testcaseName +"_"+date+ ".jpg";
			File dest = new File(screenshotPath);
			FileHandler.copy(src, dest);
			strReturnValue = dest.getAbsolutePath();
		} catch (Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Unable to take snapshot");
		}

		return strReturnValue;
	}

	/**
	 * This method is created to wait for an element presence before performing action on it
	 *
	 * @param strByObject
	 */
	public WebElement waitForPresence(By strByObject) {
		WebElement objReturnElement = null;
		try{
			WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
			System.out.println("***** B4 Element Located " + strByObject + " *****");
			objReturnElement = wait.until(ExpectedConditions.presenceOfElementLocated(strByObject));
			System.out.println("***** B4 Element Located " + strByObject + " *****");
		} catch(Exception objException)
		{
			try
			{
				WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
				objReturnElement = wait.until(ExpectedConditions.presenceOfElementLocated(strByObject));
			} catch(Exception objNestedException)
			{
				return null;
			}
		}

		System.out.println("***** B4 Element Located " + strByObject + " *****");
		return(objReturnElement);
	}

	/**
	 * This method is created to wait for an element visibility before performing action on it
	 *
	 * @param strByObject
	 */
	public WebElement waitForVisibility(By strByObject) {
		WebElement objReturnElement = null;
		try{
			WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
			objReturnElement = wait.until(ExpectedConditions.visibilityOfElementLocated(strByObject));
		} catch(Exception objException)
		{
			try
			{
				WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
				objReturnElement = wait.until(ExpectedConditions.visibilityOfElementLocated(strByObject));
			} catch(Exception objNestedException)
			{
				return null;
			}
		}

		return(objReturnElement);
	}

	/**
	 * This method is created to wait for an element clickability before performing action on it
	 *
	 * @param strByObject
	 */
	public WebElement waitForClickability(By strByObject) {
		WebElement objReturnElement = null;
		try{
			WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
			objReturnElement = wait.until(ExpectedConditions.elementToBeClickable(strByObject));
		} catch(Exception objException)
		{
			try
			{
				WebDriverWait wait = new WebDriverWait(getDriver(), GenericConstants.EXPLICIT_WAIT);
				objReturnElement = wait.until(ExpectedConditions.elementToBeClickable(strByObject));
			} catch(Exception objNestedException)
			{
				return null;
			}
		}

		return(objReturnElement);
	}

	/**
	 * This method is created to click on a webelement
	 *
	 * @param strUIName
	 * @param strByObject
	 */
	public void click(String strUIName, By strByObject) {

		WebElement objClickElement = null;
		try {
			objClickElement = waitForClickability(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else
				objClickElement.click();
		} catch (Exception objException) {
			try {
				objClickElement = waitForClickability(strByObject);
				JavascriptExecutor objJSE = (JavascriptExecutor) getDriver();
				objJSE.executeScript("argument[0].click();",objClickElement);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info(strUIName + " Element cannot be Clicked");
				Assert.fail("Cannot click the Element: " + strUIName);
			}
		}

		if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
			getExtentTest().info(strUIName + " Element Clicked");
	}

	/**
	 * This method is created to enter text in input fields
	 *
	 * @param strUIName
	 * @param strByObject
	 * @param strText
	 */
	public void sendKeys(String strUIName, By strByObject, String strText) {

		WebElement objClickElement = null;
		try {
			objClickElement = waitForClickability(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else
				objClickElement.sendKeys(strText);
		} catch (Exception objException) {
			try {
				objClickElement = waitForClickability(strByObject);
				JavascriptExecutor objJSE = (JavascriptExecutor) getDriver();
				objJSE.executeScript("argument[0]=" + strText + ";",objClickElement);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("The String: " + strText + " cannot be entered in " + strUIName);
				Assert.fail("Cannot Enter the text " + strText + "in the Element: " + strUIName);
			}
		}
		if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
			getExtentTest().info("The String: " + strText + " is entered in " + strUIName);
	}

	/**
	 * This method is created to get the text from a webelement
	 *
	 * @param strUIName
	 * @param strByObject
	 * @return
	 */
	public String getText(String strUIName, By strByObject) {

		WebElement objClickElement = null;
		String strReturnText = null;
		try {
			objClickElement = waitForVisibility(strByObject);
			if(objClickElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else
				strReturnText = objClickElement.getText();
		} catch (Exception objException) {
			try {
				objClickElement = waitForVisibility(strByObject);
				if(objClickElement==null)
					Assert.fail("Unable to locate the Element: " + strUIName);
				else
					strReturnText = objClickElement.getText();
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info(strUIName + " Element cannot be Clicked");
				Assert.fail("Cannot click the Element: " + strUIName);
			}
		}

		return(strReturnText);
	}

	/**
	 * This method is created to fetch other attributes of a webelement
	 *
	 * @param strByObject
	 * @param strAttributeName
	 */
	public void getAttribute(String strUIName, By strByObject, String strAttributeName) {

		WebElement objVisibleElement = null;
		try {
			objVisibleElement = waitForVisibility(strByObject);
			if(objVisibleElement==null)
				Assert.fail("Unable to locate the Element: " + strUIName);
			else
				objVisibleElement.getAttribute(strAttributeName);
		} catch (Exception objException) {
			try {
				objVisibleElement = waitForVisibility(strByObject);
				objVisibleElement.getAttribute(strAttributeName);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot get the Attribute value of the Attribute: " + strAttributeName +
							" of the Element " + strUIName);
				Assert.fail("Cannot get the Attribute value of the Attribute: " + strAttributeName +
						" of the Element " + strUIName);
			}
		}
	}

	/**
	 * This method is created to apply a format to the date required. Format can also be parameterized to apply different forms
	 */
	public String dateFormat()
	{
		String actualDate = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
			Date date = new Date();
			actualDate = sdf.format(date);
		} catch(Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Could not get the date format");
			Assert.fail("Could not get the date format");
		}
		return actualDate;

	}

	/**
	 * This method is created to retrieve a screenshot in base64 form
	 * @param testcaseName
	 * @return
	 */
	public String getBase64StringofScreenshot(String testcaseName)
	{
		String Base64StringOfScreenshot = null;

		try {
			String date = dateFormat();
			byte[] filecontent = new byte[0];
			File src = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
			String screenshotPath= System.getProperty("user.dir")+"/Reports/TestNG/Spark/" + testcaseName +"_"+date+ ".jpg";
			File dest = new File(screenshotPath);
			FileUtils.copyFile(src,dest);
			FileUtils.readFileToByteArray(src);
			Base64StringOfScreenshot= "data:image/png:base64"+ Base64.getEncoder().encodeToString(filecontent);
		} catch (Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Could not get the Base64 String");
			Assert.fail("Could not get the Base64 String");
		}
		return Base64StringOfScreenshot;
	}

	/**
	 * This method is created fetch the title of page
	 * @return
	 */
	public String getPageTitle() {
		String pageTitle = null;

		try {
			pageTitle = getDriver().getTitle();
		} catch(Exception objException) {
			try {
				pageTitle= getDriver().getTitle();
			} catch (Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Could not get the page title");
				Assert.fail("Could not get the page title");
			}

		}
		return pageTitle;
	}

	/**
	 * This method is created fetch the Table Element
	 * @return
	 */
	public WebElement getTable(String strUIName, By strByObject)
	{
		WebElement objVisibleElement = null;
		try {
			objVisibleElement = waitForVisibility(strByObject);
			if(objVisibleElement==null) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot get the Table: " + strUIName);
				Assert.fail("Unable to locate the Element: " + strUIName);
			}
		} catch (Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Cannot get the Table: " + strUIName);
			Assert.fail("Unable to locate the Element: " + strUIName);
		}

		return (objVisibleElement);
	}

	/**
	 * This method is created to fetch the requirement element by navigating across Shadow DOM using Xpath
	 *
	 * @param strUIName
	 * @param objDriver
	 * @param strXPathValue
	 * @return
	 */
	public WebElement NavigateShadowDOMToFindElementUsingXPath(String strUIName, WebDriver objDriver, String strXPathValue)
	{
		WebElement objElement = null;
		Shadow objShadow = null;
		try {
			objShadow = new Shadow(objDriver);
			objElement = objShadow.findElementByXPath(strXPathValue);
		} catch (Exception objException) {
			try {
				objShadow = new Shadow(objDriver);
				objElement = objShadow.findElementByXPath(strXPathValue);
			} catch (Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot get the Shadow Element: " + strUIName);
				Assert.fail("Cannot get the Shadow Element: " + strUIName);
			}
		}
		return objElement;
	}

	/**
	 * This method is created to fetch the requirement element by navigating across Shadow DOM
	 * using CSS Selector
	 * @param strUIName
	 * @param objDriver
	 * @param strCSSSelector
	 * @return
	 */
	public WebElement NavigateShadowDOMToFindElementUsingCSS(String strUIName, WebDriver objDriver, String strCSSSelector)
	{

		WebElement objElement = null;
		Shadow objShadow = null;
		try {
			objShadow = new Shadow(objDriver);
			objElement = objShadow.findElement(strCSSSelector);
		} catch (Exception objException) {
			try {
				objShadow = new Shadow(objDriver);
				objElement = objShadow.findElement(strCSSSelector);
			} catch (Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot get the Shadow Element: " + strUIName);
				Assert.fail("Cannot get the Shadow Element: " + strUIName);
			}
		}
		return objElement;
	}

	/**
	 * This method is created to switch into the iFrames using XPath
	 *
	 * @param strUIName
	 * @param objDriver
	 * @param strXPathValue
	 * @return
	 */
	public void SwitchIFramesByXPath(String strUIName, WebDriver objDriver, String strXPathValue)
	{
		WebElement objFrameElement = null;
		try {
			objFrameElement = waitForVisibility(By.xpath(strXPathValue));
			if(objFrameElement==null)
				Assert.fail("Unable to locate the Frame: " + strUIName);
			else
				getDriver().switchTo().frame(objFrameElement);
		} catch (Exception objException) {
			try {
				objFrameElement = waitForVisibility(By.xpath(strXPathValue));
				getDriver().switchTo().frame(objFrameElement);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot switch to the Frame " + strUIName);
				Assert.fail("Cannot switch to the Frame " + strUIName);
			}
		}
	}

	/**
	 * This method is created to switch into the iFrames using id
	 *
	 * @param strUIName
	 * @param objDriver
	 * @param strID
	 * @return
	 */
	public void SwitchIFramesByID(String strUIName, WebDriver objDriver, String strID)
	{
		WebElement objFrameElement = null;
		try {
			objFrameElement = waitForVisibility(By.id(strID));
			if(objFrameElement==null)
				Assert.fail("Unable to locate the Frame: " + strUIName);
			else
				getDriver().switchTo().frame(objFrameElement);
		} catch (Exception objException) {
			try {
				objFrameElement = waitForVisibility(By.id(strID));
				getDriver().switchTo().frame(objFrameElement);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot switch to the Frame " + strUIName);
				Assert.fail("Cannot switch to the Frame " + strUIName);
			}
		}
	}

	/**
	 * This method is created to switch into the iFrames using name
	 *
	 * @param strUIName
	 * @param objDriver
	 * @param strName
	 * @return
	 */
	public void SwitchIFramesByName(String strUIName, WebDriver objDriver, String strName)
	{
		WebElement objFrameElement = null;
		try {
			objFrameElement = waitForVisibility(By.name(strName));
			if(objFrameElement==null)
				Assert.fail("Unable to locate the Frame: " + strUIName);
			else
				getDriver().switchTo().frame(objFrameElement);
		} catch (Exception objException) {
			try {
				objFrameElement = waitForVisibility(By.name(strName));
				getDriver().switchTo().frame(objFrameElement);
			} catch(Exception objNestedException) {
				if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
					getExtentTest().info("Cannot switch to the Frame " + strUIName);
				Assert.fail("Cannot switch to the Frame " + strUIName);
			}
		}
	}
	/**
	 * This method is created to initialize Suite
	 * @return
	 */
	public void initializeSuite()
	{
		System.out.println("***** before Suite *****");

	}

	public void deleteDirectory(File file) {
		try {
			for (File subfile : file.listFiles()) {

				if (subfile.isDirectory()) {
					deleteDirectory(subfile);
				}
				subfile.delete();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method is used to take screenshots using selenium Base64 format
	 * @param screenshotName
	 */
	public static String getScreenshot(String screenshotName) {

		String Base64StringofScreenshot = "";
		String screenshotDir = System.getProperty("user.dir") + "/target/test-output/TestNG/Screenshot/";
		byte[] filecontent = new byte[0];
		TakesScreenshot ts = (TakesScreenshot) getDriver();
		File source = ts.getScreenshotAs(OutputType.FILE);
		Date date = new Date();
		String sDate = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss").format(date);

		try {
			FileUtils.copyFile(source, new File(screenshotDir + "screenshotName" + sDate + ".png"));
			filecontent = FileUtils.readFileToByteArray(source);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Base64StringofScreenshot = "data:image/png;base64," + Base64.getEncoder().encodeToString(filecontent);

		return Base64StringofScreenshot;
	}
}
