package utils;

import java.sql.DriverManager;
import java.sql.ResultSet;

import org.testng.Assert;

import init.InitTest;


public class SqlUtil extends InitTest{
		

	/**
	 * This method is used to run the select query which returns results as Resultset
	 * @return Resultset
	 */
	public ResultSet executeSelect(String url,String id,String pwd,String query) {


		try{
			//***Connection to Database is established via DriveManager and fetches the reuslts based on the query
			//***Resultset refers to the row and column data contained in a ResultSet object.
			
			ResultSet result=DriverManager.getConnection(url,id, pwd)
							.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY)
							.executeQuery(query);
			
			return result;
	
		}
		catch(Exception e){
			
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("*******Unable to Connect to DB " + e);
			Assert.fail("*******Unable to Connect to DB " + e);
			return null;			
		}

	}
	
	/**
	 * This method is used to run the insert,update and delete query which returns results as integer
	 * @return Integer
	 */
	public int executeUpdate(String url,String id,String pwd,String query) {


		try{
			
			//***Connection to Database is established via DriveManager and fetches the reuslts based on the query
					
			int result=DriverManager.getConnection(url,id, pwd)
							.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY)
							.executeUpdate(query);
			
			return result;
	
		}
		catch(Exception e){
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("*******Unable to Connect to DB " + e);
			Assert.fail("*******Unable to Connect to DB " + e);;
			return 0;
		}
		

	}

}
