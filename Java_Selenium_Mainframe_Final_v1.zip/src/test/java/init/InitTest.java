package init;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.FileInputStream;
import java.util.Properties;

import org.h3270.host.S3270.TerminalMode;
import org.h3270.host.S3270.TerminalType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.sf.f3270.Terminal;
import utils.FileUtil;


public class InitTest {

	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<WebDriver>();
	public static ThreadLocal<ExtentTest> tlExtentTest = new ThreadLocal<ExtentTest>();
	public static ExtentReports objExtentReport = new ExtentReports();
	public static String strFrameworkType = "BDD";
	FileUtil fileUtil = new FileUtil(System.getProperty("user.dir") + "/test-output/TestNG/Spark/");
	public Properties prop=init_prop();

	/**
	 * This method is created to initialize the threadlocal driver on the basis of given browser
	 * @param browser
	 * @return
	 */
	public static void init_driver(String browser) {
		if(browser.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			tlDriver.set(new ChromeDriver());
		}else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			tlDriver.set(new FirefoxDriver());
		}else if (browser.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			tlDriver.set(new EdgeDriver());
		}
	}

	/**
	 * This method is used to get driver with thread local
	 *
	 * @return WebDriver
	 */
	public static WebDriver getDriver() {
		return tlDriver.get();
	}
	
	
	public static ThreadLocal<Terminal> tlterminal = new ThreadLocal<Terminal>();

    /**
     * This method is created to establish a connection to mainframe terminal
     * @param hostname
     * @param port
     */
	public void init_terminal(String hostname,int port) {

		try {
			// .EXE path to 3270
			String s3270Path = prop.getProperty("mainframepath");

			// Establishing connection to mainframe
			tlterminal.set(new Terminal(s3270Path, hostname, port, TerminalType.TYPE_3279, TerminalMode.MODE_80_24,true));
						
		} catch (Exception e) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
                getExtentTest().info("Unable to connect to the server - " + hostname);
            Assert.fail("Unable to connect to the server - " + hostname);
		}
	}
	
	/**
	 * This method is used to get terminal with thread local
	 *
	 * @return Terminal
	 */
	public static Terminal getTerminal() {
		return tlterminal.get();
	}
	

	/**
	 * This method is used to get Extent Test with thread local
	 *
	 * @return ExtentTest
	 */
	public static ExtentTest getExtentTest() {
		return tlExtentTest.get();
	}

	/**
	 * This method is used to initialize Extent Test with thread local
	 *
	 * @param strTestName
	 * @param strTestDescription
	 * @return void
	 */
	public static void initExtentTest(String strTestName, String strTestDescription) {
		ExtentTest objTest = objExtentReport.createTest(strTestName,strTestDescription);
		tlExtentTest.set(objTest);
	}

	/**
	 * This method is created to load the Configuration properties from the config file
	 *
	 */

	public Properties init_prop() {
		prop = new Properties();
		try {
			FileInputStream ip = new FileInputStream("src/test/resources/configurations/config.properties");
			prop.load(ip);
		} catch (Exception objException) {
			if (InitTest.strFrameworkType.equalsIgnoreCase("TestNG"))
				getExtentTest().info("Unable to load the configuration properties from the config file");
			Assert.fail("Unable to load the configuration properties from the config file");
		}

		return prop;
	}

	/**
	 * This beforesuite method is used to initilize the report path and report details
	 */
	@BeforeSuite
	@Parameters("Framework")
	public void initSuite(String strFramework)
	{
		fileUtil.deleteDirectory();
		InitTest.strFrameworkType =  strFramework;
		ExtentSparkReporter htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/target/test-output/"+strFramework+"/testreport.html");
		objExtentReport.attachReporter(htmlReporter);
		htmlReporter.config().setDocumentTitle("Execution Report");
		htmlReporter.config().setReportName("Test Execution Report");
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
	}
}
