package bdd.stepdefinition;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import java.io.FileOutputStream;
import java.io.PrintStream;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import init.InitTest;


public class ApplicationHooks extends InitTest {


	/**
	 * This after method closes all browser/terminal session and 
	 * writes test results to Extend Report and takes screenshots
	 */
	@After
	public void tearDown(Scenario scenario) {

		String screenshotName = scenario.getName().replaceAll(" ", "_");

		if(getDriver() != null) {

			if (scenario.isFailed()) {

				byte[] sourcePath = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BYTES);
				scenario.attach(sourcePath, "image/png", screenshotName);
			}
			// closing the browser
			getDriver().quit();
		}


		if(getTerminal() != null) {

			try {
				if (scenario.isFailed()) {
					getTerminal().printScreen(new PrintStream(new FileOutputStream("target/test-output/BDD/Spark/"+screenshotName+".txt",false)),scenario.getName());

					scenario.log("<a href='"+screenshotName+".txt'>Click to View Mainframe Screen</a>");
				}
				getTerminal().disconnect();

			} catch (Exception e) {

				e.printStackTrace();
			}

		}





	}
}
