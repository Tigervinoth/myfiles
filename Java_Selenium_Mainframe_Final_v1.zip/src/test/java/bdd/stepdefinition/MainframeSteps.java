package bdd.stepdefinition;

import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.MainframeUtil;
import utils.WebUtil;

public class MainframeSteps{


	MainframeUtil mainframe=new MainframeUtil();
	WebUtil testUtil = new WebUtil();

	@Given("User is connected to mainframe host and logged in with {string} and {string}")
	public void user_is_connected_to_mainframe_host_and_logged_in_with_and(String user, String pwd) throws InterruptedException {


		// Connecting to Mainframe
		String hostname=testUtil.prop.getProperty("hostname");
		int port=Integer.parseInt(testUtil.prop.getProperty("port"));

		Thread.sleep(2000); //Demo
		
		mainframe.launchterminal(hostname, port);
		mainframe.assertText("Standard");
		
		// Sending userid and password to terminal
		mainframe.writeToField("Userid", user);
		mainframe.writeToField("Passcode", pwd);
		Thread.sleep(1500);
		System.out.println(mainframe.getfield("Userid").getValue());
		mainframe.sendEnterKey();
		// Asserting the login
		mainframe.assertText(user.toUpperCase());

	}

	@When("User navigates to ISPF primary option menu screen")
	public void user_navigates_to_ispf_primary_option_menu_screen() {

		mainframe.sendEnterKey();
		// Sending T40 command to terminal
		mainframe.writeToField("Command ===>", "t40");
		mainframe.sendEnterKey();
		mainframe.sendEnterKey();


	}

	@Then("user Validates whether all options are displayed")
	public void user_validates_whether_all_options_are_displayed() {

		mainframe.assertText("Settings");
		Assert.assertEquals(true, mainframe.checkLabel("Option ===>"));


	}

	@Then("user searches for the filename in filemenu")
	public void user_searches_for_the_filename_in_filemenu() {

		// Sending 3.4 option command to terminal to browse files
		mainframe.writeToField("Option ===>", "3.4");
		mainframe.sendEnterKey();

		// Writing the file name in terminal
		mainframe.writeToField("Dsname Level . . .", "IRBEHVB.GEN5.PROBE.CHEQUE");
		mainframe.sendEnterKey();
		mainframe.assertText("IRBEHVB.GEN5.PROBE.CHEQUE");

		// Browsing the file name in terminal
		mainframe.setCursorPOS(8, 7);
		mainframe.sendKeys("b");
		mainframe.sendEnterKey();

		// Searching some test in terminal
		mainframe.writeToField("Command ===>", "f test");
		mainframe.sendEnterKey();

		// Fetching data from terminal using field name
		System.out.println("print line "+mainframe.readFieldData("Line"));

		// Fetching data from terminal using row number
		System.out.println(mainframe.getDataFromLine(7));

	}


	@Then("user searches for the table in tablemenu")
	public void user_searches_for_the_table_in_tablemenu() {

		// Sending option 12 command to terminal to browse table
		mainframe.writeToField("Option ===>", "12");
		mainframe.sendEnterKey();
		
		// Sending A option command to terminal to browse table
		mainframe.sendKeys("A");
		mainframe.sendEnterKey();
		
		//mainframe.sendKeys("DBRD");
		mainframe.sendEnterKey();
		
		mainframe.writeToField("Option ===>", "1");
		mainframe.sendEnterKey();
		
		mainframe.writeToField("Option ===>", "T");
		mainframe.sendEnterKey();
		
		mainframe.sendTab(1);

		mainframe.assertText("PLAN_TABLE");
		
		
		
	}

}
