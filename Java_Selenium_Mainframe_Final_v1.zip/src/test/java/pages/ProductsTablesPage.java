package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import init.InitTest;
import utils.WebUtil;
import java.util.List;

public class ProductsTablesPage extends InitTest {

	WebUtil testUtil = new WebUtil();

	By addtocart=By.xpath("//button[contains(text(),'Add to cart')]");
	By cartvalidate=By.xpath("//div[@class='bar-notification success']/p");
	By closemsg=By.xpath("//span[@title='Close']");
	By gotocart=By.xpath("//span[text()='Shopping cart']");
	By checkout=By.xpath("//button[text()=' Checkout ']");
	By terms=By.id("termsofservice");


	/**
	 * This method is created to add an item to the cart
	 */
	public void addTableToCart(String strProductName) {

		testUtil.click(strProductName, addtocart);   	

	}

	public void closemsg(String strProductName) {

		testUtil.click(strProductName, closemsg);   	

	}

	public String validatecart() {

		testUtil.waitForClickability(cartvalidate);
		String accountLabel = getDriver().findElement(cartvalidate).getText();
		return accountLabel;
	}


	/**
	 * This method is created to validate items in the cart
	 *
	 * @return
	 */
	public Boolean validateCart(String selectedTableName) {
		Boolean flag = false;
		WebElement tableEle = testUtil.getTable("Main Cart Table",By.xpath("//table[@id='mainCartTable']"));
		List<WebElement> trList = tableEle.findElements(By.tagName("tr"));

		for (WebElement e : trList) {
			if (e.getText().contains(selectedTableName)) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * This method is created to perform Check out action
	 */
	public void clickCheckOut() {

		testUtil.click("Go to Cart", gotocart);
		testUtil.click("Terms and conditions", terms);
		testUtil.click("Checkout", checkout);

	}

}
