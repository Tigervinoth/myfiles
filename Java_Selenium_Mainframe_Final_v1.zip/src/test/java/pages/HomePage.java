package pages;

import org.openqa.selenium.By;
import init.InitTest;
import utils.WebUtil;

public class HomePage extends InitTest {

	WebUtil testUtil = new WebUtil();

	// *** UI elaments ***;    
	By searchbtn=By.xpath("//form/button[@type='submit']");
	By search=By.id("small-searchterms");


	/**
	 * This message is created to select table as a product
	 * @return
	 */
	public ProductsTablesPage selectProductTable(String strMainProductSegment, String searchTerm) {

		testUtil.sendKeys(strMainProductSegment, search, searchTerm);
		testUtil.click(strMainProductSegment, searchbtn);

		return new ProductsTablesPage();
	}
}
