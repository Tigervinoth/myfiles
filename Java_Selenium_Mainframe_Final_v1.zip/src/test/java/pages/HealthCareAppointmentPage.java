package pages;

import org.openqa.selenium.By;
import init.InitTest;
import utils.WebUtil;

public class HealthCareAppointmentPage extends InitTest {

	WebUtil testUtil = new WebUtil();

	// *** UI elaments ***
	By facilitydd=By.id("combo_facility");
	By program=By.id("radio_program_medicare");
	By visitdate=By.name("visit_date");
	By commentfield=By.name("comment");
	By appoitmentbtn=By.id("btn-book-appointment");
	By confirmation=By.xpath("//h2[contains(text(),'Confirmation')]");
	By programradiobtn;

	/**
	 * This method contains all the UI Actions for making health care appointment
	 */
	public void makeappointment(String facility,String program,String date,String comment) {

		testUtil.selectFromDropdownByValue("facility Dropdown", facilitydd, facility);		
		clickOnRadio(program);
		testUtil.sendKeys("Date field", visitdate, date);
		testUtil.sendKeys("Comment field", commentfield, comment);
		testUtil.click("Book Appointment", appoitmentbtn);


	}

	public void clickOnRadio(String program) {

		programradiobtn=By.xpath("//input[@value='"+program+"']");
		testUtil.click("Program", programradiobtn);
	}

	/**
	 * This method is used to validate if the confirmation message appears after making appointment
	 * @return true or false
	 */
	public Boolean validateappointment() {

		testUtil.waitForClickability(confirmation);
		if(getDriver().findElement(confirmation).isDisplayed()) return true;
		else return false;
	}
}
