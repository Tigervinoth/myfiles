package pages;

import org.openqa.selenium.By;
import init.InitTest;
import utils.WebUtil;

public class HealthCareLoginPage extends InitTest {

	WebUtil testUtil = new WebUtil();

	// *** UI elaments ***
	By appointmentbtn=By.id("btn-make-appointment");
	By username=By.name("username");
	By password=By.name("password");
	By loginbtn=By.id("btn-login");
	By makeappointmentbtn=By.id("btn-book-appointment");

	/**
	 * This method is created to validate that the user has landed on home page after login
	 *
	 * @return true or false
	 */
	public Boolean validateHomePage() {

		testUtil.waitForClickability(makeappointmentbtn);
		if(getDriver().findElement(makeappointmentbtn).isDisplayed()) return true;
		else return false;
	}
	
	public Boolean validateLoginPage() {

		testUtil.waitForClickability(loginbtn);
		if(getDriver().findElement(loginbtn).isDisplayed()) return true;
		else return false;
	}

	/**
	 * This method is created to call login module
	 *
	 * @param username
	 * @param password
	 * @return
	 */
	public HealthCareAppointmentPage login(String userName, String Password) {

		testUtil.sendKeys("User name field", username, userName);
		testUtil.sendKeys("Password Field", password, Password);
		testUtil.click("Login", loginbtn);
		return new HealthCareAppointmentPage();
	}

	public void clickOnAppoitment() {
		testUtil.click("Appointment", appointmentbtn);
	}
}
